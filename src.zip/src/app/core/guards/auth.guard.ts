import { Injector, inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const _injector = inject(Injector);
  const _router: Router = _injector.get(Router);
  let token = localStorage.getItem('token');
  if (!token) {
    alert('please login to view this page ');
    _router.navigate(['/login']);
    return false;
  }
  return true;
};
