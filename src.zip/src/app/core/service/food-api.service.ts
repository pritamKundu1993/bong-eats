import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IFood } from '../../shared/model';

@Injectable({
  providedIn: 'root',
})
export class FoodApiService {
  /**
 * .GET all foods from database :
URL :https://foodordersystem.glitch.me/api/foods
REQUEST:GET
PARAMS :None
 */
  private api_url: string = 'https://foodordersystem.glitch.me/api';
  constructor(private _http: HttpClient) {}

  public getAllFoods(): Observable<any> {
    return this._http.get(`${this.api_url}/foods`);
  }
  /**
   * 3.Adding new Food item :
URL : https://foodordersystem.glitch.me/api/food
REQUEST:POST
PARAMS: food_name , food_desc , food_price ,food_image
   */
  public addnewFood(formData: any): Observable<any> {
    return this._http.post(`${this.api_url}/food`, formData);
  }

  /**
   * Update particular food item  depends on id:
URL: https://foodordersystem.glitch.me/api/food/id
REQUEST:PUT/PATCH
PARAMS: food_name  , food_desc , food_price , food_image
   */
  public updateFood(id: string, formData: any): Observable<any> {
    return this._http.put(`${this.api_url}/food/${id}`, formData);
  }
  //https://foodordersystem.glitch.me/api/food/id
  public deleteFood(id: string) {
    return this._http.delete(`${this.api_url}/food/${id}`);
  }
}
