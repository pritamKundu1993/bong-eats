import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserApiService {
  private _userApiUrl: string = 'https://foodordersystem.glitch.me/api/user';
  constructor(private _http: HttpClient) {}

  /**user related api 
   * SignUP :
URL :https://foodordersystem.glitch.me/api/user/signup
REQEST:POST
PARAMS :name,phone,email,pass1

2.SignIn:
URL :https://foodordersystem.glitch.me/api/user/signin
REQEST:POST
PARAMS :email,pass1
  */
  Register(userData: any) {
    return this._http.post(`${this._userApiUrl}/signup`, userData);
  }

  Login(userData: any) {
    return this._http.post(`${this._userApiUrl}/signin`, userData);
  }
}
