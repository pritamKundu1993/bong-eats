export * from './home/home.component';
export * from './header/header.component';
export * from './footer/footer.component';
export * from './login/login.component';
export * from './register/register.component';
export * from './page-not-found/page-not-found.component';
