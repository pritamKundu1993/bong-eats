import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserApiService } from 'src/app/core/service';
import { IloginForm } from 'src/app/shared/model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  public loginForm!: FormGroup;
  constructor(
    private _formBuilder: FormBuilder,
    private _UserApiService: UserApiService,
    private route: Router
  ) {}
  ngOnInit(): void {
    this.loginForm = this._formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      pass1: [
        '',
        [
          Validators.minLength(3),
          Validators.required,
          Validators.pattern('^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9]).{3,}$'),
        ],
      ],
    });
  }
  public get controls() {
    return this.loginForm.controls;
  }
  onChange(controlName: string) {
    const control = this.loginForm.get(controlName);
    if (control) {
      console.log('Control:', controlName);
      console.log('Error object:', control);
    }
  }
  submitLogin() {
    console.log(this.loginForm.value);
    // const formData: IloginForm = {
    //   email: this.loginForm.value.email,
    //   pass1: this.loginForm.value.pass1,
    // };
    this._UserApiService.Login(this.loginForm.value).subscribe({
      next: (res: any) => {
        console.log(res);
        alert(res.message);
        //user data store in to browser session storage
        if (res.status === 'success') {
          localStorage.setItem('activeuser', res.activeUser);
          localStorage.setItem('token', res.token);
          /**Admin path redirect */
          this.route.navigateByUrl('/admin');
        } else {
          alert('cannot set user information');
          //redirect to login
          this.route.navigateByUrl('/login');
        }
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
}
