import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserApiService } from 'src/app/core/service';
import { IregisterForm } from 'src/app/shared/model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  public registerForm!: FormGroup;
  public showPassword: boolean = false;
  constructor(
    private _formBuilder: FormBuilder,

    private _UserApiService: UserApiService
  ) {}
  ngOnInit(): void {
    this.registerForm = this._formBuilder.group({
      name: ['', Validators.required],
      phone: [
        '',
        [
          Validators.required,
          Validators.pattern(
            '^[+]?[(]?[0-9]{3}[)]?[-s.]?[0-9]{3}[-s.]?[0-9]{4,6}$'
          ),
        ],
      ],
      email: ['', [Validators.required, Validators.email]],
      pass1: [
        '',
        [
          Validators.minLength(3),
          Validators.required,
          Validators.pattern('^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9]).{3,}$'),
        ],
      ],
    });
  }
  public get controls() {
    return this.registerForm.controls;
  }
  //toggle password
  togglePassword() {
    this.showPassword = !this.showPassword;
  }
  onChange(controlName: string) {
    const control = this.registerForm.get(controlName);
    if (control) {
      console.log('Control:', controlName);
      console.log('Error object:', control);
    }
  }
  submitRegister() {
    console.log(this.registerForm.value);
    const formData: IregisterForm = {
      name: this.registerForm.value.name,
      phone: this.registerForm.value.phone,
      email: this.registerForm.value.email,
      pass1: this.registerForm.value.pass1,
    };
    this._UserApiService.Register(formData).subscribe({
      next: (res: any) => {
        console.log(res);
        alert(res.mesaage);
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
}
