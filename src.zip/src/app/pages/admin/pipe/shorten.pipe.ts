import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shorten',
})
export class ShortenPipe implements PipeTransform {
  transform(value: string, maxLength: number): string {
    if (!value || value.length <= maxLength) {
      return value;
    }

    // Check if the character at maxLength is part of a word
    if (value[maxLength - 1] !== ' ' && value[maxLength] !== ' ') {
      let endIndex = maxLength;
      while (endIndex > 0 && value[endIndex] !== ' ') {
        endIndex--;
      }
      return value.slice(0, endIndex) + '...';
    }

    return value.slice(0, maxLength) + '...';
  }
}
