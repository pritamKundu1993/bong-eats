import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FoodApiService } from 'src/app/core/service/food-api.service';
import { IFood } from 'src/app/shared/model';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit, AfterViewInit {
  public allFoods: IFood[] = [];
  public foodObject!: any;
  public addFood!: FormGroup;
  public activeUser: string | null = '';
  constructor(
    private _foodApi: FoodApiService,
    private formBuilder: FormBuilder,
    private _router: Router
  ) {}
  /**
 * Adding new Food item :
URL : https://foodordersystem.glitch.me/api/food
REQUEST:POST
PARAMS: food_name , food_desc , food_price ,food_image
 */
  ngOnInit(): void {
    this.fetchAllFood();
    this.addFood = this.formBuilder.group({
      food_name: ['', Validators.required],
      food_desc: ['', Validators.required],
      food_price: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      food_image: [''],
    });
  }

  getLocalStorageInfo() {
    this.activeUser = localStorage.getItem('activeuser');
  }
  /**after view in it called */
  ngAfterViewInit(): void {
    /**set local storage info */
    this.getLocalStorageInfo();
  }

  fetchAllFood() {
    this._foodApi.getAllFoods().subscribe({
      next: (res: IFood[]) => {
        this.allFoods = res;
        console.log(this.allFoods);
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
  public get controls() {
    return this.addFood.controls;
  }

  /**set image file */
  setFile(event: Event) {
    console.log(event);
    const inputElement = event.target as HTMLInputElement;
    let sizeInKb = 500;
    if (inputElement.files && inputElement.files.length > 0) {
      let files = inputElement.files[0];
      if (
        (files.type === 'image/jpeg' ||
          files.type === 'image/jpg' ||
          files.type === 'image/webp') &&
        files.size <= sizeInKb * 1000
      ) {
        console.log('File selected:', files);
        this.addFood.get('food_image')?.setValue(files);
      } else {
        alert('Please choose a PDF file with a size of less 500KB.');
        inputElement.value = '';
      }
    }
    return false;
  }
  onsubmit() {
    //console.log(this.addFood.value);
    let foodFormData = new FormData();
    let formData = this.addFood.value;
    Object.keys(formData).forEach((key: any) => {
      foodFormData.append(key, formData[key]);
    });
    console.log(foodFormData);
    /**add food api call */
    this._foodApi.addnewFood(foodFormData).subscribe({
      next: (res) => {
        console.log(res);
        alert(res.message);
        /**get all food */
        this.fetchAllFood();
        /**reset the form */
        this.addFood.reset();
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
  //set food
  setFood(food: IFood) {
    console.log(food);
    this.foodObject = food;
    /**now setting up the value into my food form */
    /**
     *  food_name: ['', Validators.required],
      food_desc: ['', Validators.required],
      food_price: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      food_image: [''],
     */
    this.addFood.get('food_name')?.setValue(this.foodObject.food_name);
    this.addFood.get('food_desc')?.setValue(this.foodObject.food_desc);
    this.addFood.get('food_price')?.setValue(this.foodObject.food_price);
    this.addFood.get('food_image')?.setValue(this.foodObject.food_image);
  }
  /** update food*/
  updateFood() {
    let foodFormData = new FormData();
    let formData = this.addFood.value;
    Object.keys(formData).forEach((key: any) => {
      foodFormData.append(key, formData[key]);
    });
    //console.log(foodFormData);
    //update api call
    this._foodApi.updateFood(this.foodObject._id, foodFormData).subscribe({
      next: (res) => {
        console.log(res);
        alert(res.message);
        //get all food
        this.fetchAllFood();
        //reset the form
        this.addFood.reset();
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
  //delete food
  deleteFood(id: string) {
    console.log(id);

    this._foodApi.deleteFood(id).subscribe({
      next: (res: any) => {
        console.log(res);
        alert(res.message);
        //get all food
        this.fetchAllFood();
        this.addFood.reset();
      },
      error: (error: Error) => {
        console.error(error);
      },
    });
  }
  //logout functionalities
  logout() {
    localStorage.clear();
    //redirected to login page
    const confirmBox = confirm('are you sure you want to log out');
    if (!!confirmBox) this._router.navigate(['./login']);
  }
}
