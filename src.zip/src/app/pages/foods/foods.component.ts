import { Component, OnInit } from '@angular/core';
import { FoodApiService } from 'src/app/core/service/food-api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { IFood } from 'src/app/shared/model';
import { FilterPipe } from './pipe/filter.pipe';

@Component({
  selector: 'app-foods',
  templateUrl: './foods.component.html',
  styleUrls: ['./foods.component.css'],
})
export class FoodsComponent implements OnInit {
  public allFoods: IFood[] = [];
  public pageSize: number = 3;
  public currentPage: number = 1;
  public loading: boolean = false;
  public minPriceFilter!: number;
  public maxPriceFilter!: number;
  public searchModel!: string;

  constructor(
    private _foodApi: FoodApiService,
    private spinner: NgxSpinnerService,
    private _filterPipe: FilterPipe
  ) {}

  fetchAllFood() {
    this.loading = true;
    this.spinner.show(); // Show spinner
    this._foodApi.getAllFoods().subscribe({
      next: (res: IFood[]) => {
        this.allFoods = res;
        console.log(this.allFoods);
      },
      error: (error: Error) => {
        console.error(error);
      },
      complete: () => {
        this.loading = false;
        this.spinner.hide(); // Hide spinner
      },
    });
  }
  ngOnInit(): void {
    this.fetchAllFood();
  }

  public filterFoods(): void {
    this.currentPage = 1;
    this.allFoods = this._filterPipe.transform(
      this.allFoods,
      this.minPriceFilter,
      this.maxPriceFilter,
      this.searchModel
    );
  }
}
