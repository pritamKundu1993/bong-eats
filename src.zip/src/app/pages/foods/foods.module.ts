import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FoodsRoutingModule } from './foods-routing.module';
import { FoodsComponent } from './foods.component';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from './pipe/filter.pipe';

@NgModule({
  declarations: [FoodsComponent, FilterPipe],
  imports: [
    CommonModule,
    FoodsRoutingModule,
    NgxPaginationModule,
    NgxSpinnerModule.forRoot({ type: 'ball-scale-multiple' }),
    FormsModule,
  ],
  providers: [FilterPipe],
})
export class FoodsModule {}
