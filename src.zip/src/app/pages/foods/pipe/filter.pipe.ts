import { Pipe, PipeTransform } from '@angular/core';
import { IFood } from 'src/app/shared/model';

@Pipe({
  name: 'filter',
})
export class FilterPipe implements PipeTransform {
  public transform(foods: IFood[], ...args: unknown[]): IFood[] {
    if (!foods) return [];

    const [minimumPrice, maximumPrice, searchTerm] = args.map((arg) =>
      (<string>(arg || '')).trim()
    );

    if (this.invalidPriceRange(minimumPrice, maximumPrice)) return foods;

    return foods.filter(
      (item) =>
        this.meetsMinPrice(item, minimumPrice) &&
        this.meetsMaxPrice(item, maximumPrice) &&
        this.meetsSearchTerm(item, searchTerm)
    );
  }

  private invalidPriceRange(
    minimumPrice: string,
    maximumPrice: string
  ): boolean {
    return !!minimumPrice && !!maximumPrice && +minimumPrice > +maximumPrice;
  }

  private meetsMinPrice(item: IFood, minimumPrice: string): boolean {
    return (
      !minimumPrice || isNaN(+minimumPrice) || item.food_price >= +minimumPrice
    );
  }

  private meetsMaxPrice(item: IFood, maximumPrice: string): boolean {
    return (
      !maximumPrice || isNaN(+maximumPrice) || item.food_price <= +maximumPrice
    );
  }

  private meetsSearchTerm(item: IFood, searchTerm: string): boolean {
    return (
      !searchTerm ||
      item.food_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }
}
