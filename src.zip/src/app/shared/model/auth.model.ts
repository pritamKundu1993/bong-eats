export interface IregisterForm {
  name: string;
  phone: string;
  email: string;
  pass1: string;
}
export interface IloginForm {
  email: string;
  pass1: string;
}
