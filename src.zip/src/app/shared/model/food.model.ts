export interface IFood {
  food_desc: string;
  food_image: string;
  food_name: string;
  food_price: number;
  _id: string;
}
